package com.example.guessnum;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;




public class MainActivity extends AppCompatActivity {
TextView info_les_larger;
EditText input_num;
Button mainButton;
Button exitButton;
int conceived;
int typed_num;
boolean status=false;
boolean flag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        info_les_larger=(TextView)findViewById(R.id.textView2);
        input_num=(EditText)findViewById(R.id.editTextNumber);
        mainButton=(Button)findViewById(R.id.button2);
        conceived = (int) (Math.random()*101);
        exitButton=(Button)findViewById(R.id.button);
    }


    public void onClick(View v){
        flag=true;
        try{
            typed_num=Integer.parseInt(input_num.getText().toString());
        }
        catch (Exception ex)
        {
            flag=false;
            info_les_larger.setText(getResources().getString(R.string.error));
        }
        if(flag){
            mainButton.setText(getResources().getString(R.string.input_num));
            if (typed_num > 100 || typed_num > 100) {
                info_les_larger.setText(getResources().getString(R.string.error));
            }
            else if (typed_num > conceived) {
                info_les_larger.setText(getResources().getString(R.string.smaller));
            } else if (typed_num < conceived) {
                info_les_larger.setText(getResources().getString(R.string.larger));
            } else if (typed_num == conceived) {
                info_les_larger.setText(getResources().getString(R.string.answer));
                status = true;
            } else if (status) {
                mainButton.setText(getResources().getString(R.string.again));
                status = false;
                conceived = (int) (Math.random() * 101);
            }
        }
    }
}
